// Mock Data
const notices = [
    {
        id: 1,
        platform: 'naver',
        category: 'notice',
        productType: 'search',
        title: '[공지] 파워링크 검색 노출 로직 변경 안내',
        desc: '네이버 검색광고 파워링크의 관련도 산출 로직이 일부 변경됩니다. 새로운 로직 적용으로 인해 광고 노출 순위에 변동이 있을 수 있습니다.',
        content: '안녕하세요. 네이버 검색광고 운영자입니다.\n\n파워링크 광고의 노출 순위 품질을 개선하기 위해 관련도 산출 로직이 오는 5월부터 새롭게 적용될 예정입니다.\n\n새로운 로직은 광고주의 키워드와 사용자 의도간의 연관성을 더욱 정교하게 분석합니다.\n적용 이후 일부 키워드에서 노출 순위가 변동될 수 있으므로, 광고주 여러분께서는 노출 및 클릭 추이를 주의 깊게 모니터링해주시기 바랍니다.\n\n감사합니다.',
        url: 'https://saedu.naver.com/notice',
        date: '2026.04.15'
    },
    {
        id: 2,
        platform: 'kakao',
        category: 'product',
        productType: 'display',
        title: '[신규상품] 카카오비즈보드 확장형 동영상 지면 오픈',
        desc: '카카오톡 상단 비즈보드 영역에 동영상을 자동으로 재생할 수 있는 확장형 지면이 새롭게 오픈되었습니다.',
        content: '안녕하세요. 카카오비즈니스입니다.\n\n많은 광고주분들이 기다리셨던 카카오비즈보드 프리미엄 확장형 동영상 상품이 정식 오픈되었습니다.\n사용자가 탭을 확장하면 동영상이 사운드와 함께 재생되어 몰입도를 극대화할 수 있습니다.\n\n소재 등록 가이드라인은 고객센터의 첨부문서를 확인해주세요.',
        url: 'https://business.kakao.com/notice',
        date: '2026.04.14'
    },
    {
        id: 3,
        platform: 'google',
        category: 'policy',
        productType: 'all',
        title: '[정책] 금융 서비스 광고 정책 업데이트',
        desc: '구글 애즈 금융 상품 및 서비스 관련 광고 정책이 강화됩니다. 가상화폐 관련 광고주분들은 인증 절차를 다시 확인해주세요.',
        content: 'Google Ads 정책이 업데이트됩니다.\n\n금융 상품에 관한 규제가 강화됨에 따라, 특히 가상화폐 및 관련 서비스에 대한 광고 인벤토리 정책이 변경됩니다.\n해당 산업군의 광고주는 사전에 신원 확인 및 규제 준수 증명 서류를 제출해야 광고 노출이 가능합니다.\n\n상세한 인증 절차는 정책 센터를 확인하세요.',
        url: 'https://support.google.com/google-ads/answer/2375414',
        date: '2026.04.13'
    },
    {
        id: 4,
        platform: 'meta',
        category: 'error',
        productType: 'display',
        title: '[장애안내] 인스타그램 피드 광고 노출 지연 현상 (복구완료)',
        desc: '일부 계정에서 인스타그램 피드 광고 스폰서드 마크가 정상 노출되지 않던 현상이 모두 복구되었습니다.',
        content: '장애 복구 완료 안내\n\n4월 11일 오후 2시경부터 발생했던 인스타그램 피드 내 스폰서드 표기 오류 및 도달 지연 현상이 모두 복구되었습니다.\n해당 시간 동안 발생한 청구 금액은 자동 필터링되어 광고비에 반영되지 않습니다.\n\n이용에 불편을 드려 대단히 죄송합니다.',
        url: 'https://www.facebook.com/business/help',
        date: '2026.04.12'
    },
    {
        id: 5,
        platform: 'daangn',
        category: 'product',
        productType: 'search',
        title: '[업데이트] 당근마켓 지역검색광고 키워드 추천 기능 추가',
        desc: '광고주 센터에 지역 기반으로 검색량이 높은 키워드를 자동으로 추천해주는 기능이 도입되었습니다.',
        content: '당근 비즈니스가 더 스마트해졌습니다!\n\n이제 광고를 등록하실 때 내 가게 주변 당근 이웃들이 가장 많이 검색하는 핫한 키워드를 자동으로 추천해 드립니다.\n추천 키워드를 활용해 매장 홍보 효과를 높여보세요!',
        url: 'https://business.daangn.com/board',
        date: '2026.04.10'
    },
    {
        id: 6,
        platform: 'naver',
        category: 'operation',
        productType: 'shopping',
        title: '[운영] 쇼핑검색광고 - 쇼핑몰 휴무일 설정 가이드',
        desc: '다가오는 연휴 기간 동안 쇼핑검색광고 운영에 필요한 휴무일 설정 및 일예산 관리 가이드를 안내해 드립니다.',
        content: '연휴 대비 쇼핑검색광고 운영 가이드\n\n연휴 기간 택배 발송이 지연되는 경우, 고객의 불만을 방지하기 위해 네이버 스마트스토어 휴무일 설정 및 쇼핑검색광고 노출 스케줄을 조정하시기 바랍니다.\n- 스케줄 설정 방법: 광고관리 시스템 > 그룹 수정 > 노출 일정\n\n감사합니다.',
        url: 'https://saedu.naver.com/notice',
        date: '2026.04.09'
    },
    {
        id: 7,
        platform: 'google',
        category: 'product',
        productType: 'video',
        title: '[상품] 유튜브 Shorts 광고 인벤토리 확대',
        desc: '유튜브 쇼츠 탭 내 동영상 액션 캠페인 노출 지면이 기존 대비 30% 확대 적용됩니다.',
        content: 'YouTube Shorts 광고 노출 확대 안내\n\n동영상 액션 캠페인(VAC)을 사용하시는 광고주분들은 이제 더욱 넓어진 Shorts 인벤토리를 통해 폭발적인 도달을 경험할 수 있습니다.\nShorts 지면에 최적화된 세로형(9:16) 에셋을 필수적으로 추가하는 것을 권장합니다.',
        url: 'https://support.google.com/google-ads',
        date: '2026.04.08'
    },
    {
        id: 8,
        platform: 'kakao',
        category: 'policy',
        productType: 'search',
        title: '[심사] 브랜드 검색 키워드 심사 기준 강화',
        desc: '카카오 키워드광고 브랜드 등록 시 요구되는 상표권 증빙 서류 기준이 강화되었습니다. 공지 본문을 확인하시기 바랍니다.',
        content: '키워드광고 심사 기준 변경\n\n브랜드 검색 보호를 위해, 등록하려는 키워드와 브랜드명 간의 관계를 증명할 수 있는 상표권 서류 제출이 의무화됩니다.\n서류 미비 시 심사가 반려될 수 있으니 미리 준비해주시기 바랍니다.',
        url: 'https://business.kakao.com/notice',
        date: '2026.04.05'
    },
    {
        id: 9,
        platform: 'meta',
        category: 'notice',
        productType: 'all',
        title: '[공지] 메타 비즈니스 매니저 UI 개편 사전 안내',
        desc: '더욱 직관적인 광고 관리를 위해 메타 비즈니스 매니저 디자인이 대폭 개편될 예정입니다. 베타 버전을 먼저 체험해보세요.',
        content: '새로운 Meta 비즈니스 환경 커밍순!\n\n캠페인, 세트, 광고 단계를 한 눈에 볼 수 있는 새로운 분할 화면 디자인이 도입됩니다.\n우측 상단 [새로운 디자인 사용해보기] 토글을 통해 베타 버전을 경험하고 피드백을 남겨주세요.',
        url: 'https://business.facebook.com/',
        date: '2026.04.02'
    },
    {
        id: 10,
        platform: 'others',
        category: 'policy',
        productType: 'display',
        title: '[토스] 디스플레이 광고소재 가이드라인 변경',
        desc: '토스 앱 내 배너 광고 소재 제작 시 폰트 크기 및 여백 규정이 일부 변경되었습니다.',
        content: '토스 광고 소재 제작 가이드라인 업데이트\n\n토스 앱의 UI 업데이트에 따라, 네이티브 배너의 가독성을 높이기 위해 최소 텍스트 크기가 12pt에서 14pt로 상향 조정됩니다.\n또한 안전 영역(Safe Area) 여백이 늘어났으니, 새로운 템플릿을 다운로드하여 작업해주시기 바랍니다.',
        url: 'https://toss.im',
        date: '2026.04.01'
    }
];

// Configuration for mapping
const platformConfig = {
    naver: { name: '네이버', color: '#03C75A', bg: 'rgba(3, 199, 90, 0.15)' },
    kakao: { name: '카카오', color: '#FEE500', bg: 'rgba(254, 229, 0, 0.15)' },
    google: { name: '구글', color: '#4285F4', bg: 'rgba(66, 133, 244, 0.15)' },
    meta: { name: '메타', color: '#1877F2', bg: 'rgba(24, 119, 242, 0.15)' },
    daangn: { name: '당근마켓', color: '#FF7E36', bg: 'rgba(255, 126, 54, 0.15)' },
    others: { name: '기타', color: '#8B5CF6', bg: 'rgba(139, 92, 246, 0.15)' }
};

const categoryConfig = {
    notice: { name: '공지/이벤트', color: '#3B82F6' },
    product: { name: '상품/서비스', color: '#10B981' },
    policy: { name: '정책/심사', color: '#F59E0B' },
    error: { name: '오류/장애', color: '#EF4444' },
    operation: { name: '운영', color: '#8B5CF6' }
};

const productConfig = {
    all: { name: '공통/전체' },
    search: { name: '검색광고' },
    display: { name: '디스플레이광고' },
    shopping: { name: '쇼핑광고' },
    video: { name: '동영상광고' }
};

// State
let currentPlatform = 'all';
let currentCategory = 'all';
let currentProduct = 'all';
let searchQuery = '';

// DOM Elements
const noticeGrid = document.getElementById('notice-grid');
const resultsCount = document.querySelector('.results-count span');
const searchInput = document.getElementById('search-input');

const platformTabs = document.querySelectorAll('.platform-tab');
const categoryTabs = document.querySelectorAll('.category-tab');
const productChips = document.querySelectorAll('.product-chip');

// Modal Elements
const modal = document.getElementById('notice-modal');
const modalClose = document.getElementById('modal-close');
const modalPlatform = document.getElementById('modal-platform');
const modalDate = document.getElementById('modal-date');
const modalTitle = document.getElementById('modal-title');
const modalCategory = document.getElementById('modal-category');
const modalProduct = document.getElementById('modal-product');
const modalBody = document.getElementById('modal-body-content');
const modalLink = document.getElementById('modal-link');

// Initialize
function init() {
    setupEventListeners();
    renderNotices();
}

function setupEventListeners() {
    // Platform Click
    platformTabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            platformTabs.forEach(t => t.classList.remove('active'));
            e.target.classList.add('active');
            currentPlatform = e.target.dataset.platform;
            renderNotices();
        });
    });

    // Category Click
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            categoryTabs.forEach(t => t.classList.remove('active'));
            e.target.classList.add('active');
            currentCategory = e.target.dataset.category;
            renderNotices();
        });
    });

    // Product Click
    productChips.forEach(chip => {
        chip.addEventListener('click', (e) => {
            productChips.forEach(c => c.classList.remove('active'));
            e.target.classList.add('active');
            currentProduct = e.target.dataset.product;
            renderNotices();
        });
    });

    // Search Input
    searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.toLowerCase();
        renderNotices();
    });

    // Close Modal
    modalClose.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal();
    });
}

function openModal(noticeId) {
    const notice = notices.find(n => n.id === noticeId);
    if (!notice) return;

    const platConf = platformConfig[notice.platform];
    const catConf = categoryConfig[notice.category];
    const prodConf = productConfig[notice.productType] || { name: notice.productType };

    // Set styling and data
    modalPlatform.textContent = platConf.name;
    modalPlatform.style.color = platConf.color;
    modalPlatform.style.background = platConf.bg;

    modalDate.textContent = notice.date;
    modalTitle.textContent = notice.title;
    modalBody.textContent = notice.content || notice.desc;
    
    modalCategory.textContent = catConf.name;
    modalCategory.style.color = catConf.color;
    modalCategory.style.background = `${catConf.color}15`;
    modalCategory.style.borderColor = `${catConf.color}30`;
    
    modalProduct.textContent = prodConf.name;
    modalLink.href = notice.url || '#';

    // Show modal
    modal.classList.add('active');
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
}

function closeModal() {
    modal.classList.remove('active');
    document.body.style.overflow = '';
}

function filterNotices() {
    return notices.filter(notice => {
        const matchPlatform = currentPlatform === 'all' || notice.platform === currentPlatform;
        const matchCategory = currentCategory === 'all' || notice.category === currentCategory;
        const matchProduct = currentProduct === 'all' || notice.productType === currentProduct;
        const matchSearch = notice.title.toLowerCase().includes(searchQuery) || notice.desc.toLowerCase().includes(searchQuery);
        
        return matchPlatform && matchCategory && matchProduct && matchSearch;
    });
}

function renderNotices() {
    const filtered = filterNotices();
    resultsCount.textContent = filtered.length;
    
    noticeGrid.innerHTML = '';
    
    if (filtered.length === 0) {
        noticeGrid.innerHTML = `
            <div class="empty-state">
                <span class="material-icons-round">search_off</span>
                <h2>검색 결과가 없습니다.</h2>
                <p>필터 조건을 변경하거나 검색어를 다르게 입력해보세요.</p>
            </div>
        `;
        return;
    }

    filtered.forEach((notice, index) => {
        const platConf = platformConfig[notice.platform];
        const catConf = categoryConfig[notice.category];
        const prodConf = productConfig[notice.productType] || { name: notice.productType };

        const card = document.createElement('div');
        card.className = 'notice-card';
        card.style.setProperty('--platform-color', platConf.color);
        card.style.setProperty('--platform-bg', platConf.bg);
        // Staggered animation delay
        card.style.animationDelay = `${index * 0.05}s`;

        card.innerHTML = `
            <div class="card-header">
                <span class="platform-badge" style="color: ${platConf.color}">${platConf.name}</span>
                <span class="date">${notice.date}</span>
            </div>
            <div class="card-body">
                <h3>${notice.title}</h3>
                <p>${notice.desc}</p>
            </div>
            <div class="card-footer">
                <span class="tag" style="color: ${catConf.color}; background: ${catConf.color}15; border-color: ${catConf.color}30;">
                    ${catConf.name}
                </span>
                <span class="tag tag-product">
                    ${prodConf.name}
                </span>
            </div>
        `;
        
        card.addEventListener('click', () => openModal(notice.id));
        
        noticeGrid.appendChild(card);
    });
}

// Run
document.addEventListener('DOMContentLoaded', init);
